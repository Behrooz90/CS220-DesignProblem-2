package designproblem2;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
//write-up in submitted google form
public class Zombies {
	 Map<String, String> zmap;

	public Zombies() {
		zmap = new TreeMap<String, String>();// for quick organized results
	}

	public static void main(String[] args) {
		Zombies z = new Zombies();
		z.addZombie("Walker", "Slow and weak");
		z.addZombie("Runner", "Can be tricked");
		z.addZombie("Bigslow", "Slow");
		z.addZombie("Ghoul", "Dies without head");
		z.addZombie("Aggressive", "Easily distracted");
		System.out.println("Determine zombie weakness? Y or N");
		Scanner obj = new Scanner(System.in);
		String input = obj.next();
		if (input.equalsIgnoreCase("Y")) {
			System.out.println("Enter zombie type: Choose Walker, Runner, Bigslow, Ghoul, or Aggressive");
			String type = obj.next();
			z.determine(type);
		}
		if (input.equalsIgnoreCase("N")) {
			System.out.println("New zombie type? Y or N");
			String ans = obj.next();
			if (ans.equalsIgnoreCase("Y")) {
				System.out.println("Enter type: ");
				String type = obj.next();
				System.out.println("Enter weakness: ");
				String weakness = obj.next();
				z.addZombie(type, weakness);
			}
			if (ans.equalsIgnoreCase("N")) {
				System.out.println("Continue surviving");
			}
		}
	}

	 String determine(String query) {
		if (zmap.containsKey(query))
			return(zmap.get(query));
		else
			return ("Non Existant type");
	}
	
	 void addZombie(String type, String weakness) {
		zmap.put(type, weakness);
		System.out.println("Thanks for your contribution to the cause.");
	}
	 
	boolean hasZombie(String type) {
		if(zmap.containsKey(type))
			return true;
		else
			return false;
	}
}
