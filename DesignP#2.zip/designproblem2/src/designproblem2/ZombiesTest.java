package designproblem2;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

//import designproblem.Game;

public class ZombiesTest {
	
	private Zombies z;

	@Before
	public void setUp() throws Exception {
		z = new Zombies();
		z.addZombie("Walker", "Slow and weak");
		z.addZombie("Runner", "Can be tricked");
		z.addZombie("Bigslow", "Slow");
		z.addZombie("Ghoul", "Dies without head");
		z.addZombie("Aggressive", "Easily distracted");
	}

	@Test
	public void testDetermine() {
		assertEquals("Slow and weak",z.determine("Walker"));
		assertEquals("Can be tricked",z.determine("Runner"));
		assertEquals("Slow",z.determine("Bigslow"));
		assertEquals("Dies without head",z.determine("Ghoul"));
		assertEquals("Easily distracted",z.determine("Aggressive"));
	}
	
	@Test
	public void testaddZombie() {
		z.addZombie("Plant", "Fire");
		assertEquals(true,z.hasZombie("Plant"));
		assertEquals("Fire",z.determine("Plant"));

	}

}
